<?php $__env->startSection('head'); ?>
<title>DELI | Thay đổi khách hàng</title>
<link rel="stylesheet" href="<?php echo e(secure_asset('plugins/select2/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>
  
<?php $__env->startSection('main'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>THAY ĐỔI KHÁCH HÀNG</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Trang chủ</a></li>
              <li class="breadcrumb-item active">Thay đổi khách hàng</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
    <?php if(count($errors) > 0): ?> 
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <div class="alert alert-danger alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h4><i class="icon fa fa-ban"></i> Thất bại!</h4> <?php echo $error; ?>

      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <form action="<?php echo e(route('staff.coursestudent.edit.post', ['id'=>$course_student->id])); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="id" value="<?php echo e($course_student->id); ?>"/>
    <input type="hidden" name="client_id" value="<?php echo e($course_student->client_id); ?>"/>
    <div class="row">
      <div class="col-md-12">
        <div class="card card-primary">
          <div class="card-body">
            <div class="col-md-12">
              <div class="form-group col-md-12">
                <label>TÊN KHÁCH HÀNG:</label>
                <input type="text" class="form-control" value="<?php echo e($course_student->client->name); ?>" disabled>
              </div>
              <div class="form-group col-md-12">
                <label>TÊN KHÁCH HÀNG:</label>
                <input type="text" class="form-control" value="<?php echo e($course_student->client->name); ?>" disabled>
              </div>
              <div class="form-group col-md-12">
                <label>SỐ ĐIỆN THOẠI:</label>
                <input type="text" class="form-control" value="<?php echo e($course_student->client->phone); ?>" disabled>
              </div>
              <div class="form-group col-md-12">
                <label>NGÀNH NGHỀ KINH DOANH:</label>
                <input type="text" class="form-control" value="<?php echo e($course_student->client->major); ?>" disabled>
              </div>
              <div class="form-group col-md-12">
                <label>DỰ ÁN THIẾT KẾ:</label>
                <select name="course_id" class="form-control select2" style="width: 100%;">
                  <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($data->id); ?>" <?php if($data->id==$course_student->course_id): ?> selected="selected" <?php endif; ?>><?php echo e($data->shortname); ?> - <?php echo e($data->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group col-md-12">
                <label>PHẦN TRĂM ƯU ĐÃI:</label>
                <input type="number" class="form-control" name="deal_rate" value="<?php echo e($course_student->deal_rate); ?>" required>
              </div>
              <div class="form-group col-md-12">
                <label>SỐ TIỀN ĐÃ THU:</label>
                <input type="number" class="form-control" name="tuition_done" value="<?php echo e($course_student->tuition_done); ?>" required>
              </div>
              <div class="form-group col-md-12">
                <label>CHƯƠNG TRÌNH ƯU ĐÃI:</label>
                <input type="textarea" class="form-control" name="deal_note" value="<?php echo e($course_student->deal_note); ?>" placeholder="Ghi rõ nội dung ưu đãi" required>
              </div>
              <div class="form-group col-md-12">
                <label>NHÂN VIÊN:</label>
                <select name="staff_id" id="staff_id" class="form-control select2" style="width: 100%;">
                  <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($data->id); ?>" <?php if($data->id == UserInfo()->id): ?> checked <?php endif; ?> ><?php echo e($data->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group col-md-12">
                <label>GHI CHÚ:</label>
                <input type="textarea" class="form-control" name="content" value="<?php echo e($course_student->content); ?>" placeholder="Một vài dòng tâm sự...">
              </div>
            </div>
          </div>
          <div class="card-footer">
            <button type="submit" class="btn btn-primary pull-right">Lưu thay đổi</button>
            <a onclick="history.go(-1);" class="btn">Quay lại</a>
          </div>
        </div>
      </div>
    </div>
    </form>
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- bootstrap datepicker -->
<script language="JavaScript" type="text/javascript" src="<?php echo e(asset('/plugins/jquery/jquery.min.js')); ?>"></script>
<script language="JavaScript" type="text/javascript" src="<?php echo e(asset('/plugins/select2/select2.full.min.js')); ?>"></script>
<script>
/* global $ */
  $(function () {
    $('.select2').select2()
  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/delineco/sys.deli4ne1.com/resources/views/student-edit.blade.php ENDPATH**/ ?>