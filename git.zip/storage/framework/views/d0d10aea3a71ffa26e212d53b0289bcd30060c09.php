<?php $__env->startSection('head'); ?>
<title>DELI | Thêm khách hàng</title>
<link rel="stylesheet" href="<?php echo e(secure_asset('plugins/select2/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>
  
<?php $__env->startSection('main'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>THÊM KHÁCH HÀNG VÀO DỰ ÁN</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Trang chủ</a></li>
              <li class="breadcrumb-item active">Thêm khách hàng vào dự án</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
    <?php if(count($errors) > 0): ?> 
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <div class="alert alert-danger alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h4><i class="icon fa fa-ban"></i> Thất bại!</h4> <?php echo $error; ?>

      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <form action="<?php echo e(route('staff.coursestudent.add.post')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="client_id" value="<?php echo e($client->id); ?>"/>
    <div class="row">
      <div class="col-md-12">
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">NHẬP THÔNG TIN KHÁCH HÀNG VÀO DỰ ÁN</h3>
          </div>
          <div class="card-body">
            <div class="col-md-12">
              <div class="form-group col-md-12">
                <label>TÊN KHÁCH HÀNG:</label>
                <input type="text" class="form-control" value="<?php echo e($client->name); ?>" disabled>
              </div>
              <div class="form-group col-md-12">
                <label>SỐ ĐIỆN THOẠI:</label>
                <input type="text" class="form-control" value="<?php echo e($client->phone); ?>" disabled>
              </div>
              <div class="form-group col-md-12">
                <label>NGÀNH NGHỀ KINH DOANH:</label>
                <input type="text" class="form-control" value="<?php echo e($client->major); ?>" disabled>
              </div>
              <div class="form-group col-md-12">
                <label>DỰ ÁN THIẾT KẾ:</label>
                <select name="course_id" class="form-control select2" style="width: 100%;">
                  <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($data->sum()<$data->maxseat): ?>
                  <option value="<?php echo e($data->id); ?>"><?php echo e($data->shortname); ?> - <?php echo e($data->name); ?> (<?php echo e($data->sum()); ?>/<?php echo e($data->maxseat); ?>)</option>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group col-md-12">
                <label>PHẦN TRĂM ƯU ĐÃI:</label>
                <input type="number" class="form-control" name="deal_rate" value="<?php echo e(old('deal_rate')); ?>" required>
              </div>
              <div class="form-group col-md-12">
                <label>SỐ TIỀN ĐÃ THU:</label>
                <input type="number" class="form-control" name="tuition_done" value="<?php echo e(old('tuition_done')); ?>" required>
              </div>
              <div class="form-group col-md-12">
                <label>CHƯƠNG TRÌNH ƯU ĐÃI:</label>
                <input type="textarea" class="form-control" name="deal_note" value="<?php echo e(old('deal_note')); ?>" placeholder="Ghi rõ nội dung ưu đãi">
              </div>
              <div class="form-group col-md-12">
                <label>NHÂN VIÊN:</label>
                <select name="staff_id" id="staff_id" class="form-control select2" style="width: 100%;">
                  <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($data->id); ?>" <?php if($data->id == UserInfo()->id): ?> checked <?php endif; ?> ><?php echo e($data->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="form-group col-md-12">
                <label>GHI CHÚ:</label>
                <input type="textarea" class="form-control" name="note" value="<?php echo e(old('note')); ?>" placeholder="Một vài dòng tâm sự...">
              </div>
            </div>
          </div>
          <div class="card-footer">
            <button type="submit" class="btn btn-primary pull-right">Thêm Khách hàng vào dự án</button>
          </div>
        </div>
      </div>
    </div>
    </form>
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- bootstrap datepicker -->
<script language="JavaScript" type="text/javascript" src="<?php echo e(asset('/plugins/jquery/jquery.min.js')); ?>"></script>
<script language="JavaScript" type="text/javascript" src="<?php echo e(asset('/plugins/select2/select2.full.min.js')); ?>"></script>
<script>
/* global $ */
  $(function () {
    $('.select2').select2()
  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/delineco/sys.deli4ne1.com/resources/views/student-add.blade.php ENDPATH**/ ?>