<?php $__env->startSection('head'); ?>
<title>DELI | Sửa thông tin khách hàng: <?php echo e($client->ten); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>THAY ĐỔI THÔNG TIN KHÁCH HÀNG</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Trang chủ</a></li>
              <li class="breadcrumb-item active">Thay đổi thông tin khách hàng</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
    
    <?php if(count($errors) > 0): ?> 
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <div class="alert alert-danger alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h4><i class="icon fa fa-ban"></i> Thất bại!</h4> <?php echo $error; ?>

      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
      <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Nhập thông tin khách hàng</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" action="<?php echo e(route('staff.client.edit.post', ['client_id' => $client->id])); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="card-body">
                  <div class="form-group">
                    <label for="phone">Số điện thoại:</label>
                    <input name="phone" pattern="[0-9]{10}" class="form-control" id="phone" value="<?php echo e($client->phone); ?>" autofocus required>
                  </div>
                  <div class="form-group">
                    <label for="name">Tên khách hàng:</label>
                    <input name="name" type="text" class="form-control" id="name" value="<?php echo e($client->name); ?>" required>
                  </div>
                  <div class="form-group">
                    <label for="birthday">Ngày sinh:</label>
                    <input name="birthday" type="date" class="form-control" id="birthday" value="<?php echo e($client->birthday); ?>">
                  </div>
                  <div class="form-group">
                    <label for="fburl">Facebook:</label>
                    <input name="fburl" type="text" class="form-control" id="fburl" value="<?php echo e($client->fburl); ?>">
                  </div>
                  <div class="form-group">
                    <label for="zalo">Zalo:</label>
                    <input name="zalo" type="number" class="form-control" id="zalo" value="<?php echo e($client->zalo); ?>" >
                  </div>
                  <div class="form-group">
                    <label for="email">Email:</label>
                    <input name="email" type="text" class="form-control" id="email" value="<?php echo e($client->email); ?>" >
                  </div>
                  <div class="form-group">
                    <label for="major">Ngành nghề kinh doanh:</label>
                    <input name="major" type="text" class="form-control" id="major" value="<?php echo e($client->major); ?>" >
                  </div>
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Lưu thay đổi</button>
                  <a onclick="history.go(-1);" class="btn">Quay lại</a>
                </div>
              </form>
            </div>
            <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/delineco/sys.deli4ne1.com/resources/views/client-edit.blade.php ENDPATH**/ ?>