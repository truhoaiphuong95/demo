<?php $__env->startSection('head'); ?>
<title>DELI | Sửa báo cáo</title>
<link rel="stylesheet" href="<?php echo e(secure_asset('plugins/select2/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>BÁO CÁO CÔNG VIỆC</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo e(route('staff.dashboard.view.get')); ?>">Trang chủ</a></li>
            <li class="breadcrumb-item active">Báo cáo</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <?php if(count($errors) > 0): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <h4><i class="icon fa fa-ban"></i> Thất bại!</h4> <?php echo $error; ?>

      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      <form action="<?php echo e(route('staff.worklog.edit.post', ['worklog_id' => $worklog->id])); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="row">
          <div class="col-md-12">
            <div class="card card-primary">
              <div class="card-body">
                <div class="col-md-12">
                  <div class="form-group col-md-12" >
                    <label>Ngày làm việc:</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                      </div>
                      <input type="date" name="date" class="form-control" value="<?php echo e($worklog -> date); ?>" required>
                    </div>
                    <!-- /.input group -->
                  </div>
                  <div class="form-group col-md-12">
                    <label>Chọn ca làm việc</label>
                    <select name="session" class="form-control select2" style="width: 100%;" required>
                      <?php $__currentLoopData = $session; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($key == $worklog->session): ?>
                      <option value="<?php echo e($key); ?>" checked><?php echo e($value); ?></option>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="col-md-12">
                    <label>Nội dung công việc</label>
                    <textarea id="editor1" name="content" style="width: 100%" placeholder="Nội dung công việc chi tiết"><?php echo e($worklog -> content); ?></textarea>
                  </div>
                  <!-- /.col-->
                  <!-- <div class="form-group col-md-12">
                    <label>Nội dung công việc</label>
                    <textarea name="content" class="form-control" rows="3" placeholder="Mỗi công việc nhập một dòng, chi tiết và cụ thể"></textarea>
                  </div> -->
                </div>
              </div>
              <div class="card-footer">
                <button type="submit" class="btn btn-primary pull-right">Gửi báo cáo</button>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- bootstrap datepicker -->
<script language="JavaScript" type="text/javascript" src="<?php echo e(asset('/plugins/jquery/jquery.min.js')); ?>"></script>
<script language="JavaScript" type="text/javascript" src="<?php echo e(asset('/plugins/select2/select2.full.min.js')); ?>"></script>
<script language="JavaScript" type="text/javascript" src="<?php echo e(asset('/plugins/ckeditor/ckeditor.js')); ?>"></script>
<script>
  /* global $ */
  $(function() {
    $('.select2').select2()
    ClassicEditor
      .create(document.querySelector('#editor1'))
      .then(function(editor) {
        // The editor instance
      })
      .catch(function(error) {
        console.error(error)
      })
  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/delineco/sys.deli4ne1.com/resources/views/worklog-edit.blade.php ENDPATH**/ ?>