<?php $__env->startSection('head'); ?>
<title>DELI | Thông tin biên nhận #<?php echo e($ticket->id); ?></title>
<link rel="stylesheet" href="<?php echo e(secure_asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<link rel="stylesheet" href="<?php echo e(secure_asset('plugins/iCheck/square/blue.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>THÔNG TIN BIÊN NHẬN</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Trang chủ</a></li>
            <li class="breadcrumb-item active">Thông tin biên nhận</li>
          </ol>
        </div>
      </div>
    </div>
    <!-- /.container-fluid -->
  </section>
  <section class="content">
    <div class="container-fluid">
      <?php if(session('success')): ?>
      <div class="row">
        <div class="col-md-12">
          <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h5><i class="icon fa fa-check"></i> Thành công!</h5>
            <?php echo e(session('success')); ?>

          </div>
        </div>
      </div>
      <?php endif; ?>
      <?php if(session('error')): ?>
      <div class="row"><div class="col-md-12">
        <div class="alert alert-danger alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h5><i class="icon fa fa-ban"></i> Thất bại!</h5> 
          <?php echo e(session('error')); ?>

        </div>
      </div></div>
      <?php endif; ?>
      <div class="row">
        <div class="col-md-6">
          <!-- Main content -->
          <div class="invoice p-3 mb-3">
            <!-- title row -->
            <div class="row">
              <div class="col-12">
                <h4>
                  <i class="fa fa-wrench"></i> <b>THÔNG TIN BIÊN NHẬN THIẾT KẾ</b>
                  <small class="float-right"><b>SỐ PHIẾU #<?php echo e($ticket->id); ?></b></small>
                </h4>
              </div>
              <!-- /.col -->
            </div>
            <!-- info row -->
            <div class="row invoice-info">
              <div class="col-md-8 invoice-col">
                <u>THÔNG TIN KHÁCH HÀNG:</u>
                <address>
                  <strong class="text-uppercase"><?php echo $ticket->client->linkName(); ?></strong><br>
                  <b>Số điện thoại:</b> <?php echo ($ticket->client->linkPhone()); ?><br>
                  <b>Ngày sinh:</b> <?php echo e(date("d/m/Y", strtotime($ticket->client->birthday))); ?><br>
                  <b>Mã khách hàng:</b> KH<?php echo e($ticket->client->id); ?><br>
                  <b>Ngày nhận:</b> <?php echo e($ticket->created_at->timezone('Asia/Ho_Chi_Minh')->format("d/m/Y - H:i")); ?><br>
                  <b>Nhân viên nhận:</b> <b><?php echo e($ticket->staff->name); ?></b>
                </address>
              </div>
              <!-- /.col -->
              <div class="col-md-4">
                <div class="btn-group" style="width: 100%">
                  <div class="btn btn-<?php echo e($ticket->ticketStatus->class); ?>" style="width: 100%"><?php echo e($ticket->ticketStatus->name); ?></div>
                  <button type="button" class="btn btn-<?php echo e($ticket->ticketStatus->class); ?> dropdown-toggle" data-toggle="dropdown">
                    <span class="caret"></span>
                    <span class="sr-only">Toggle Dropdown</span>
                  </button>
                  <div class="dropdown-menu" role="menu">
                    <?php $__currentLoopData = $ticket_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($data->id == 3): ?> 
                    <a class="dropdown-item" onclick="checkDone()"><?php echo e($data->name); ?></a>
                    <?php else: ?>
                    <a class="dropdown-item" href="<?php echo e(route('staff.ticket.changestatus.get', ['ticket_id'=>$ticket->id, 'status_id'=>$data->id])); ?>"><?php echo e($data->name); ?></a>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
            <!-- Table row -->
            <div class="row">
              <div class="col-12">
                <address>
                  <h5 class="text-uppercase"><b>YÊU CẦU CỦA KHÁCH HÀNG:</b> 
                  <?php $__currentLoopData = $ticket->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($service->name); ?>, 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($ticket->requestment); ?></h5>
                </address>
              </div>
            </div>
            <!-- /.row -->
            <!-- Table row -->
            <div class="row">
              <div class="col-12 table-responsive">
                <table class="table table-striped table table-bordered">
                  <tbody>
                    <tr>
                      <td class="text-uppercase" style="width: 200px"><b>TÊN THƯƠNG HIỆU</b></h5>
                      </td>
                      <td class="text-uppercase"><?php echo e($ticket -> model); ?></h5>
                      </td>
                    </tr>
                    <tr>
                      <td class="text-uppercase" style="width: 200px"><b>MÀU SẮC</b></h5>
                      </td>
                      <td class="text-uppercase"><?php echo e($ticket -> cpu); ?></h5>
                      </td>
                    </tr>
                    <tr>
                      <td class="text-uppercase" style="width: 200px"><b>MÔ TẢ YÊU CẦU</b></h5>
                      </td>
                      <td class="text-uppercase"><?php echo e($ticket -> ram); ?></h5>
                      </td>
                    </tr>
                    <tr>
                      <td class="text-uppercase" style="width: 200px"><b>PHONG CÁCH</b></h5>
                      </td>
                      <td class="text-uppercase"><?php echo e($ticket -> storage); ?></h5>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="col-12 table-responsive">
                <table class="table table-striped table table-bordered">
                  <tbody>
                    <tr>
                      <td class="text-uppercase" style="width: 200px"><b>BỐ CỤC MONG MUỐN</b></h5>
                      </td>
                      <td class="text-uppercase"><?php echo e($ticket -> note); ?></h5>
                      </td>
                    </tr>
                    <tr>
                      <td class="text-uppercase" style="width: 200px"><b>IN ẤN</b></h5>
                      </td>
                      <td class="text-uppercase"><?php echo e($ticket -> other); ?></h5>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.col -->
            </div>
            <div class="row no-print">
              <div class="col-12">
                <a href="<?php echo e(route('staff.client.edit.get', ['client_id' => $ticket->client->id])); ?>" class="btn btn-default">Thay đổi thông tin Khách hàng</a>
                <a href="<?php echo e(route('staff.ticket.edit.get', ['ticket_id' => $ticket->id])); ?>" class="btn btn-default">Sửa biên nhận</a>
                <div class="btn-group float-right">
                  <a href="<?php echo e(route('staff.ticket.printpos.get', ['ticket_id' => $ticket->id])); ?>" target="_blank" class="btn btn-primary" id="btnIn"><i class="fa fa-print"></i>&nbsp;&nbsp;IN MÁY POS</a>
                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                    <span class="caret"></span>
                    <span class="sr-only">Toggle Dropdown</span>
                  </button>
                  <div class="dropdown-menu" role="menu">
                    <a class="dropdown-item" href="<?php echo e(route('staff.ticket.print.get', ['ticket_id' => $ticket->id])); ?>" target="_blank">IN BIÊN NHẬN</a>
                  </div>
                </div>
                
                <a href="<?php echo e(route('staff.ticket.printinternal.get', ['ticket_id' => $ticket->id])); ?>" target="_blank" class="btn btn float-right"><i class="fa fa-print"></i>&nbsp;&nbsp;IN PHIẾU DÁN</a>
              </div>
            </div>
          </div>
          <!-- /.invoice -->
        </div>
        <div class="col-md-6">
          <?php if($ticket->price != NULL): ?>
          <div class="row">
            <div class="col-md-12">
              <div class="alert bg-maroon alert-primary">
                <h5><i class="icon fa fa-money"></i>TỔNG CỘNG: <span style="font-size:1.5rem;font-weight: bold;"><?php if($ticket->price==0): ?> MIỄN PHÍ <?php else: ?> <?php echo e(MoneyFormat($ticket->price)); ?> VNĐ <?php endif; ?></span> </h5>
              </div>
            </div>
          </div>
          <?php endif; ?>
          <div class="card card-info">
            <div class="card-header">
              <h3 class="card-title">TRAO ĐỔI - GÓP Ý - NHẬN XÉT</h3>
            </div>
            <div class="card-body">
              <div class="col-md-12">
                <form action="<?php echo e(route('staff.ticketlog.add.post')); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                  <div class="input-group">
                    <input name="content" type="text" class="form-control" placeholder="Nhập nội dung..." required>
                    <input name="ticket_id" type="hidden" value="<?php echo e($ticket->id); ?>" />
                    <input name="staff_id" type="hidden" value="<?php echo e(UserInfo()->id); ?>" />
                  </div>
                  <div class="row my-2">
                    <div class="col-md-8">
                      <div class="checkbox icheck">
                        <label>
                          <input name="is_public" type="hidden" value="0">
                          <input name="is_public" type="checkbox" value="1"> Công khai cho Khách hàng xem!!!
                        </label>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <button type="submit" class="btn btn-info btn-flat float-right">Thêm!</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">NHẬT KÝ TRAO ĐỔI</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr class="text-center">
                    <th>THỜI GIAN</th>
                    <th>NỘI DUNG TRAO ĐỔI</th>
                    <th>NGƯỜI VIẾT</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $ticket->ticketLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($data->created_at->timezone('Asia/Ho_Chi_Minh')->format("d/m/Y - H:i")); ?></td>
                    <td>
                      <?php if($data->is_public): ?>
                      <a style="color: #0a0" href="<?php echo e(route('staff.ticketlog.setpublic.get', ['ticketlog_id' => $data->id])); ?>" alt="Đang công khai, ấn để thay đổi">
                        <i class="fa fa-globe"></i>
                      </a>&nbsp;
                      <?php else: ?>
                      <a style="color: #a00" href="<?php echo e(route('staff.ticketlog.setpublic.get', ['ticketlog_id' => $data->id])); ?>">
                        <i class="fa fa-times"></i>
                      </a>&nbsp;
                      <?php endif; ?> <?php echo e($data->content); ?>

                    </td>
                    <td><?php echo e($data->staff->name); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(secure_asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(secure_asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
<!-- iCheck -->
<script src="<?php echo e(secure_asset('plugins/iCheck/icheck.min.js')); ?>"></script>
<script>
  $(function() {
    $("#example1").DataTable({
      "paging": false,
      "lengthChange": false,
      "searching": false,
      "ordering": false,
      "info": false,
      "autoWidth": true,
    });
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    })
  });
  window.onkeydown = function(evt) {
    if (evt.keyCode == 119) //F8
      document.getElementById("btnIn").click();
  };
  function checkDone() {
    var price;
    var input = prompt("Nhập vào phí dịch vụ:");
    if (input == null ) {
      return;
    } else {
      price = input;
    }
    window.location.href = "<?php echo e(route('staff.ticket.changestatus.get', ['ticket_id'=>$ticket->id, 'status_id'=>3])); ?>/"+price;
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/delineco/sys.deli4ne1.com/resources/views/ticket-view.blade.php ENDPATH**/ ?>