<?php $__env->startSection('head'); ?>
<title>KING | Thống kê tài chính</title>
<link rel="stylesheet" href="<?php echo e(secure_asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<style>
  .pagination li {
    padding: 10px;
  }
  .pagination {
    float: right;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Thống kê kỹ thuật</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Trang chủ</a></li>
            <li class="breadcrumb-item active">Thống kê</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-header no-border">
            <div class="d-flex justify-content-between">
              <h3 class="card-title">Số lượng máy nhận năm 2020</h3>
            </div>
          </div>
          <div class="card-body">
            <div class="d-flex">
              <p class="d-flex flex-column">
                <span class="text-bold text-lg"><?php echo e($ticket_sum); ?></span>
                <span>Lượt trong năm nay</span>
              </p>
              <p class="ml-auto d-flex flex-column text-right">
                <?php if($ticket_growth>0): ?>
                <span class="text-success">
                  <i class="fa fa-arrow-up"></i> <?php echo e($ticket_growth); ?>%
                </span>
                <?php else: ?>
                <span class="text-danger">
                  <i class="fa fa-arrow-down"></i> <?php echo e($ticket_growth); ?>%
                </span>
                <?php endif; ?>
                <span class="text-muted">So với tháng trước</span>
              </p>
            </div>
            <!-- /.d-flex -->

            <div class="position-relative mb-4">
              <canvas id="tickets-chart"></canvas>
            </div>

            <div class="d-flex flex-row justify-content-end">
              <span class="mr-2">
                <i class="fa fa-square text-primary"></i> Số lượng biên nhận kỹ thuật
              </span>
            </div>
          </div>
        </div>
        <!-- /.card -->
      </div>
      <div class="col-lg-12">
        <div class="card">
          <div class="card-header no-border">
            <div class="d-flex justify-content-between">
              <h3 class="card-title">Số lượng học viên đăng ký năm 2020</h3>
            </div>
          </div>
          <div class="card-body">
            <div class="d-flex">
              <p class="d-flex flex-column">
                <span class="text-bold text-lg"><?php echo e($student_sum); ?></span>
                <span>Lượt trong năm nay</span>
              </p>
              <p class="ml-auto d-flex flex-column text-right">
                <?php if($student_growth>0): ?>
                <span class="text-success">
                  <i class="fa fa-arrow-up"></i> <?php echo e($student_growth); ?>%
                </span>
                <?php else: ?>
                <span class="text-danger">
                  <i class="fa fa-arrow-down"></i> <?php echo e($student_growth); ?>%
                </span>
                <?php endif; ?>
                <span class="text-muted">So với tháng trước</span>
              </p>
            </div>
            <!-- /.d-flex -->

            <div class="position-relative mb-4">
              <canvas id="students-chart"></canvas>
            </div>

            <div class="d-flex flex-row justify-content-end">
              <span class="mr-2">
                <i class="fa fa-square text-primary"></i> Số lượng biên nhận kỹ thuật
              </span>
            </div>
          </div>
        </div>
        <!-- /.card -->
      </div>

      <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-lg-7">
        <div class="card">
          <div class="card-header no-border">
            <div class="d-flex justify-content-between">
              <h3 class="card-title">Tài chính <?php echo e($field->name); ?> năm 2020</h3>
            </div>
          </div>
          <div class="card-body">
            <div class="d-flex">
              <p class="d-flex flex-column">
                <span class="text-bold text-lg"><span class="text-success"><?php echo e(MoneyFormat($receipt_sum[$f])); ?></span><span class="text-danger"> - <?php echo e(MoneyFormat($payment_sum[$f])); ?></span> = <?php echo e(MoneyFormat($receipt_sum[$f]-$payment_sum[$f])); ?></span>
                <span>Doanh thu - Chi phí = Lợi nhuận</span>
              </p>
              <p class="ml-auto d-flex flex-column text-right">
                <?php if($receipt_growth[$f]>0): ?>
                <span class="text-success">
                  <i class="fa fa-arrow-up"></i> <?php echo e($receipt_growth[$f]); ?>%
                </span>
                <?php else: ?>
                <span class="text-danger">
                  <i class="fa fa-arrow-down"></i> <?php echo e($receipt_growth[$f]); ?>%
                </span>
                <?php endif; ?>
                <span class="text-muted">So với tháng trước</span>
              </p>
            </div>
            <!-- /.d-flex -->

            <div class="position-relative mb-4">
              <canvas id="<?php echo e($field->key); ?>-fin-chart"></canvas>
            </div>

            <div class="d-flex flex-row justify-content-end">
              <span class="mr-2">
                <i class="fa fa-square text-success"></i> Thu
                <i class="fa fa-square text-danger"></i> Chi
                <i class="fa fa-square text-primary"></i> Lợi nhuận
              </span>
            </div>
          </div>
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col-md-12 -->
      <div class="col-lg-5">
        <div class="card card-primary">
          <div class="card-body">
            <table class="table table-bordered">
              <tbody>
                <tr>
                  <th></th>
                  <th>Thu</th>
                  <th>Chi</th>
                  <th>Lợi nhuận</th>
                </tr>
                <?php for($i=0; $i<6; $i++): ?>
                <tr>
                  <td>Tháng <?php echo e($i+1); ?></td> 
                  <td><?php echo e(MoneyFormat($receipt_count[$f][$i])); ?></td>
                  <td><?php echo e(MoneyFormat($payment_count[$f][$i])); ?></td>
                  <td><?php echo e(MoneyFormat($receipt_count[$f][$i]-$payment_count[$f][$i])); ?></td>
                </tr>
                <?php endfor; ?>
              </tbody>
            </table>
          </div>
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col-md-12 -->
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(secure_asset('plugins/chart.js/Chart.min.js')); ?>"></script>
<script>
  $(function() {
    'use strict'
    var ticksStyle = {
      fontColor: '#495057',
      fontStyle: 'bold'
    }
    var mode = 'index'
    var intersect = true
    var $ticketsChart = $('#tickets-chart')
    var ticketsChart = new Chart($ticketsChart, {
      data: {
        labels: [
          'Tháng 1',
          'Tháng 2',
          'Tháng 3',
          'Tháng 4',
          'Tháng 5',
          'Tháng 6',
          'Tháng 7',
          'Tháng 8',
          'Tháng 9',
          'Tháng 10',
          'Tháng 11',
          'Tháng 12'
        ],
        datasets: [{
          type: 'line',
          data: [
            <?php $__currentLoopData = $ticket_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo e($data); ?>,
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          ],
          backgroundColor: 'transparent',
          borderColor: '#007bff',
          pointBorderColor: '#007bff',
          pointBackgroundColor: '#007bff',
          fill: false
          // pointHoverBackgroundColor: '#007bff',
          // pointHoverBorderColor    : '#007bff'
        }]
      },
      options: {
        maintainAspectRatio: false,
        tooltips: {
          mode: mode,
          intersect: intersect
        },
        hover: {
          mode: mode,
          intersect: intersect
        },
        legend: {
          display: false
        },
        scales: {
          yAxes: [{
            // display: false,
            gridLines: {
              display: true,
              lineWidth: '4px',
              color: 'rgba(0, 0, 0, .2)',
              zeroLineColor: 'transparent'
            },
            ticks: $.extend({
              beginAtZero: true,
              suggestedMax: 100
            }, ticksStyle)
          }],
          xAxes: [{
            display: true,
            gridLines: {
              display: false
            },
            ticks: ticksStyle
          }]
        }
      }
    })
    var $studentsChart = $('#students-chart')
    var studentsChart = new Chart($studentsChart, {
      data: {
        labels: [
          'Tháng 1',
          'Tháng 2',
          'Tháng 3',
          'Tháng 4',
          'Tháng 5',
          'Tháng 6',
          'Tháng 7',
          'Tháng 8',
          'Tháng 9',
          'Tháng 10',
          'Tháng 11',
          'Tháng 12'
        ],
        datasets: [{
          type: 'line',
          data: [
            <?php $__currentLoopData = $student_count; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
              <?php echo e($data); ?>,
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          ],
          backgroundColor: 'transparent',
          borderColor: '#007bff',
          pointBorderColor: '#007bff',
          pointBackgroundColor: '#007bff',
          fill: false
          // pointHoverBackgroundColor: '#007bff',
          // pointHoverBorderColor    : '#007bff'
        }]
      },
      options: {
        maintainAspectRatio: false,
        tooltips: {
          mode: mode,
          intersect: intersect
        },
        hover: {
          mode: mode,
          intersect: intersect
        },
        legend: {
          display: false
        },
        scales: {
          yAxes: [{
            // display: false,
            gridLines: {
              display: true,
              lineWidth: '4px',
              color: 'rgba(0, 0, 0, .2)',
              zeroLineColor: 'transparent'
            },
            ticks: $.extend({
              beginAtZero: true,
              suggestedMax: 100
            }, ticksStyle)
          }],
          xAxes: [{
            display: true,
            gridLines: {
              display: false
            },
            ticks: ticksStyle
          }]
        }
      }
    })
    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    var $<?php echo e($field->key); ?>Chart = $('#<?php echo e($field->key); ?>-fin-chart')
    var <?php echo e($field->key); ?>Chart = new Chart($<?php echo e($field->key); ?>Chart, {
        data: {
          labels: [
            'Tháng 1',
            'Tháng 2',
            'Tháng 3',
            'Tháng 4',
            'Tháng 5',
            'Tháng 6',
            'Tháng 7',
            'Tháng 8',
            'Tháng 9',
            'Tháng 10',
            'Tháng 11',
            'Tháng 12'
          ],
          datasets: [{
              type: 'line',
              data: [
                <?php $__currentLoopData = $receipt_count[$f]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <?php echo e($data); ?>,
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              ],
              backgroundColor: 'transparent',
              borderColor: '#28a745',
              pointBorderColor: '#28a745',
              pointBackgroundColor: '#28a745',
              fill: false
              // pointHoverBackgroundColor: '#007bff',
              // pointHoverBorderColor    : '#007bff'
            },
            {
              type: 'line',
              data: [
                <?php $__currentLoopData = $payment_count[$f]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <?php echo e($data); ?>,
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              ],
              backgroundColor: 'tansparent',
              borderColor: '#dc3545',
              pointBorderColor: '#dc3545',
              pointBackgroundColor: '#dc3545',
              fill: false
              // pointHoverBackgroundColor: '#ced4da',
              // pointHoverBorderColor    : '#ced4da'
            },
            {
              type: 'line',
              data: [
                <?php $__currentLoopData = $receipt_count[$f]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <?php echo e($data - $payment_count[$f][$i]); ?>,
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              ],
              backgroundColor: 'tansparent',
              borderColor: '#007bff',
              pointBorderColor: '#007bff',
              pointBackgroundColor: '#007bff',
              fill: false
              // pointHoverBackgroundColor: '#ced4da',
              // pointHoverBorderColor    : '#ced4da'
            }
          ]
        },
        options: {
          maintainAspectRatio: false,
          tooltips: {
            mode: mode,
            intersect: intersect
          },
          hover: {
            mode: mode,
            intersect: intersect
          },
          legend: {
            display: false
          },
          scales: {
            yAxes: [{
              // display: false,
              gridLines: {
                display: true,
                lineWidth: '4px',
                color: 'rgba(0, 0, 0, .2)',
                zeroLineColor: 'transparent'
              },
              ticks: $.extend({
                beginAtZero: true,
                suggestedMax: 100,
                callback(value) {
                  return Number(value).toLocaleString('en')
                }
              }, ticksStyle)
            }],
            xAxes: [{
              display: true,
              gridLines: {
                display: false
              },
              ticks: ticksStyle
            }]
          },
        }
      })
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  });
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/delineco/sys.deli4ne1.com/resources/views/statistic-finance-year.blade.php ENDPATH**/ ?>