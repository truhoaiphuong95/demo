<?php $__env->startSection('head'); ?>
<title>DELI | Danh sách dịch vụ</title>
<link rel="stylesheet" href="<?php echo e(secure_asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<style>
  .pagination li {
    padding: 10px; 
  }
  .pagination {
    float: right;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>DANH SÁCH DỊCH VỤ</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Trang chủ</a></li>
              <li class="breadcrumb-item active">Dịch vụ</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">DANH SÁCH DỊCH VỤ</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr class="text-center">
                  <th>ID</th>
                  <th>NGÀY TẠO</th>
                  <th>TÊN DỊCH VỤ</th>
                  <th>NHÓM</th>
                  <th>PHÍ DỊCH VỤ</th>
                  <th>SỐ LẦN</th>
                  <th>HÀNH ĐỘNG</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="text-center"><?php echo e($service->id); ?></td>
                  <td class="text-center"><?php echo e(date("d/m/Y", strtotime($service->created_at))); ?></td>
                  <td class="text-uppercase"><b><?php echo e($service->name); ?></b></td>
                  <td><?php echo e($service->sku); ?></td>
                  <td class="text-right text-danger"><b><?php echo e(MoneyFormat($service->price)); ?></b></td>
                  <td class="text-center"><?php echo e($service->tickets_count); ?></td>
                  <td class="text-center">
                    <div class="btn-group">
                      <a href="<?php echo e(route('staff.service.edit.get', ['service_id' => $service->id])); ?>" class="btn btn-primary">Sửa</a>
                      <?php if(UserInfo()->level >= 2): ?>
                      <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                        <span class="caret"></span>
                        <span class="sr-only">Toggle Dropdown</span>
                      </button>
                      <div class="dropdown-menu" role="menu">
                        <a class="dropdown-item" href="<?php echo e(route('staff.service.delete.get', ['service_id' => $service->id])); ?>">Xoá</a>
                      </div>
                      <?php endif; ?>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(secure_asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(secure_asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
<script>
  $(function () {
    $("#example1").DataTable({
        // "order": false,
        "order": [[ 4, "desc" ]],
        "lengthMenu": [ 500 ],
        "bPaginate": false,
        "language": {
        	"sProcessing":   "Đang xử lý...",
        	"sLengthMenu":   "Xem _MENU_ mục",
        	"sZeroRecords":  "Không tìm thấy dòng nào phù hợp",
        	"sInfo":         "Đang xem _START_ đến _END_ trong tổng số _TOTAL_ mục",
        	"sInfoEmpty":    "Đang xem 0 đến 0 trong tổng số 0 mục",
        	"sInfoFiltered": "(được lọc từ _MAX_ mục)",
        	"sInfoPostFix":  "",
        	"sSearch":       "Tìm:",
        	"sUrl":          "",
        	"oPaginate": {
        		"sFirst":    "Đầu",
        		"sPrevious": "Trước",
        		"sNext":     "Tiếp",
        		"sLast":     "Cuối"
        	}
        }
    });
  });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/delineco/sys.deli4ne1.com/resources/views/service-list.blade.php ENDPATH**/ ?>