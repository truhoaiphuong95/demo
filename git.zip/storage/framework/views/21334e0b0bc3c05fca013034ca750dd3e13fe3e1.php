<?php $__env->startSection('head'); ?>
<title>DELI | Danh sách biên nhận</title>
<link rel="stylesheet" href="<?php echo e(secure_asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<style>
  .pagination li {
    padding: 10px; 
  }
  .pagination {
    float: right;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>DANH SÁCH BIÊN NHẬN THIẾT KẾ</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Trang chủ</a></li>
              <li class="breadcrumb-item active">Danh sách biên nhận thiết kế</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">DANH SÁCH BIÊN NHẬN THIẾT KẾ</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr class="text-center">
                  <th>SỐ PHIẾU</th>
                  <th>TÊN KHÁCH HÀNG</th>
                  <th>DỊCH VỤ</th>
                  <th>NGÀY NHẬN</th>
                  <th>NGÀY GIAO</th>
                  <th>TIẾN ĐỘ</th>
                  <th>BÁO GIÁ</th>
                  <th>HÀNH ĐỘNG</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="text-center"><a href="<?php echo e(route('staff.ticket.view.get', ['ticket_id' => $ticket->id])); ?>">#<?php echo e($ticket->id); ?></a></td>
                  <td class="text-uppercase"><?php echo e($ticket->client->name); ?></td>
                  <td>
                    <?php $__currentLoopData = $ticket->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php echo e($service->name); ?>,
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($ticket->requestment); ?>

                  </td>
                  <td class="text-center"><?php echo e($ticket->created_at->timezone('Asia/Ho_Chi_Minh')->format("d/m/Y")); ?></td>
                  <td class="text-center"><?php echo e($ticket->storage); ?></td>
                  <td class="text-center">
                    <span class="badge bg-<?php echo e($ticket->ticketStatus->class); ?>"><span style="display: none;"><?php echo e($ticket->ticketStatus->id); ?></span><?php echo e($ticket->ticketStatus->name); ?></span>
                  </td>
                  <td class="text-right"><?php if(isset($ticket->price)): ?> <?php if($ticket->price==0): ?> MIỄN PHÍ <?php else: ?> <?php echo e(MoneyFormat($ticket->price)); ?> VNĐ <?php endif; ?> <?php endif; ?></td>
                  <td class="text-center">
                    <div class="btn-group">
                      <a href="<?php echo e(route('staff.ticket.view.get', ['ticket_id' => $ticket->id])); ?>" class="btn btn-primary">Xem</a>
                      <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                        <span class="caret"></span>
                        <span class="sr-only">Toggle Dropdown</span>
                      </button>
                      <div class="dropdown-menu" role="menu">
                        <a class="dropdown-item" href="<?php echo e(route('staff.ticket.printpos.get', ['ticket_id' => $ticket->id])); ?>" target="_blank">In máy POS</a>
                        <a class="dropdown-item" href="<?php echo e(route('staff.ticket.printinternal.get', ['ticket_id' => $ticket->id])); ?>" target="_blank">In phiếu dán</a>
                        <a class="dropdown-item" href="<?php echo e(route('staff.ticket.print.get', ['ticket_id' => $ticket->id])); ?>" target="_blank">In biên nhận</a>
                      </div>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(secure_asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
<script src="<?php echo e(secure_asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
<script>
  $(function () {
    $("#example1").DataTable({
        // "order": false,
        "order": [[ 3, "asc" ]],
        "lengthMenu": [ 500 ],
        "bPaginate": false,
        "language": {
        	"sProcessing":   "Đang xử lý...",
        	"sLengthMenu":   "Xem _MENU_ mục",
        	"sZeroRecords":  "Không tìm thấy dòng nào phù hợp",
        	"sInfo":         "Đang xem _START_ đến _END_ trong tổng số _TOTAL_ mục",
        	"sInfoEmpty":    "Đang xem 0 đến 0 trong tổng số 0 mục",
        	"sInfoFiltered": "(được lọc từ _MAX_ mục)",
        	"sInfoPostFix":  "",
        	"sSearch":       "Tìm:",
        	"sUrl":          "",
        	"oPaginate": {
        		"sFirst":    "Đầu",
        		"sPrevious": "Trước",
        		"sNext":     "Tiếp",
        		"sLast":     "Cuối"
        	}
        }
    });
  });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/delineco/sys.deli4ne1.com/resources/views/ticket-list.blade.php ENDPATH**/ ?>