<?php $__env->startSection('head'); ?>
<title>DELI | Nhập phiếu thu</title>
<link rel="stylesheet" href="<?php echo e(secure_asset('plugins/select2/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>NHẬP THÔNG TIN PHIẾU THU</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Trang chủ</a></li>
            <li class="breadcrumb-item active">Nhập thông tin phiếu thu</li>
          </ol>
        </div>
      </div>
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- Main content -->
  <section class="content">
    <?php if(count($errors) > 0): ?> 
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <div class="col-md-12">
      <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <h5><i class="icon fa fa-ban"></i> Thất bại!</h5>
        <?php echo $error; ?>

      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <!-- general form elements -->
    <div class="col-md-12">
      <div class="card card-primary">
        <div class="card-header">
          <h3 class="card-title">NHẬP THÔNG TIN PHIẾU THU</h3>
        </div>
        <!-- /.card-header -->
        <!-- form start -->
        <form role="form" action="<?php echo e(route('staff.receipt.add.post')); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <div class="card-body">
            <div class="form-group">
              <label>Tên Khách hàng:</label> <?php echo e($client->name); ?>   |   
              <label>Số Điện Thoại:</label> <?php echo e($client->phone); ?>    |    
              <label>Ngày Sinh:</label> <?php echo e($client->birthday); ?>

              <input name="client_id" type="hidden" class="form-control" value="<?php echo e($client->id); ?>">
            </div>
            <div class="form-group">
              <label for="content">Nội dung thu:</label>
              <input name="content" type="text" class="form-control" id="content" placeholder="Ví dụ: Thiết kế Logo" autofocus required>
            </div>
            <div class="form-group">
              <label for="amount">Số tiền:</label>
              <input name="amount" type="number" class="form-control" id="amount" placeholder="Nhập vào số tiền" required>
            </div>
            <div class="form-group">
              <label>Ngày lập phiếu:</label>
              <input type="date" min="2018-01-01" class="form-control" name="created_at" value="" required>
            </div>
            <div class="form-group">
              <label for="branch_id">Chi nhánh:</label>
              <select name="branch_id" id="branch_id" class="form-control select2" style="width: 100%;">
                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="form-group">
              <label for="staff_id">Người lập phiếu:</label>
              <select name="staff_id" id="staff_id" class="form-control select2" style="width: 100%;">
                <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($data->id); ?>" <?php if($data->id == UserInfo()->id): ?> checked <?php endif; ?> ><?php echo e($data->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="form-group">
              <label for="field_id">Danh mục thu:</label>
              <select name="field_id" id="field_id" class="form-control select2" style="width: 100%;">
                <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="form-group">
              <label for="note">Ghi chú:</label>
              <input name="note" type="text" class="form-control" id="note" placeholder="Nội dung ghi chú">
            </div>
          </div>
          <!-- /.card-body -->
          <div class="card-footer">
            <button type="submit" class="btn btn-primary">Thêm vào</button>
            <a onclick="history.go(-1);" class="btn">Quay lại</a>
          </div>
        </form>
      </div>
    </div>
    <!-- /.card -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- Select2 -->
<script src="<?php echo e(secure_asset('plugins/select2/select2.full.min.js')); ?>"></script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/delineco/sys.deli4ne1.com/resources/views/receipt-add.blade.php ENDPATH**/ ?>