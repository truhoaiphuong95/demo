<?php $__env->startSection('main'); ?>
<div class="card card-info">
  <div class="card-header">
    <h3 class="card-title">THÔNG TIN KHÁCH HÀNG</h3>
  </div>
  <div class="card-body">
    <table class="table table-bordered">
      <tbody>
        <tr>
          <td colspan="2">
            <address>
              <strong class="text-uppercase"><?php echo e($ticket->client->name); ?></strong><br>
              <b>Số điện thoại:</b> <?php echo e(PhoneFormat($ticket->client->phone)); ?><br>
              <b>Ngày sinh:</b> <?php echo e(date("d/m/Y", strtotime($ticket->client->birthday))); ?><br>
              <b>Mã khách hàng:</b> KH<?php echo e($ticket->client->id); ?><br>
              <b>Ngày nhận:</b> <?php echo e($ticket->created_at->timezone('Asia/Ho_Chi_Minh')->format("d/m/Y - H:i")); ?><br>
              <b>Nhân viên nhận:</b> <?php echo e($ticket->staff->name); ?>

            </address>
          </td>
        </tr>
        <tr>
          <td>Tên thương hiệu:</td>
          <td><?php echo e($ticket->model); ?> </td>
        </tr>
        <tr>
          <td>Lĩnh vực kinh doanh:</td>
          <td><?php echo e($ticket->requestment); ?> </td>
        </tr>
        <tr>
          <td>Màu sắc:</td>
          <td><?php echo e($ticket->cpu); ?> </td>
        </tr>
        <tr>
          <td>Mô tả yêu cầu:</td>
          <td><?php echo e($ticket->ram); ?> </td>
        </tr>
        <tr>
          <td>Phong cách thiết kế:</td>
          <td><?php echo e($ticket->storage); ?> </td>
        </tr>
        <tr>
          <td>Bố cục thiết kế mà bạn mong muốn? (Ngang/Dọc):</td>
          <td><?php echo e($ticket->note); ?> </td>
        </tr>
        <tr>
          <td>Đặt in ấn:</td>
          <td><?php echo e($ticket->other); ?> </td>
        </tr>
      </tbody>
    </table>
  </div>
  <!-- /.card-footer -->
</div>
<div class="card card-info">
  <div class="card-header">
    <h3 class="card-title">THEO DÕI TIẾN ĐỘ THIẾT KẾ</h3>
  </div>
  <div class="card-body">
    <table class="table table-bordered">
      <tbody>
        <tr class="text-center">
          <th>THỜI GIAN</th>
          <th>NỘI DUNG</th>
        </tr>
        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td class="text-center"><?php echo e(date("d/m/Y - h:i", strtotime($data->created_at))); ?></td>
          <td><i class="fa fa-globe"></i>&nbsp; <?php echo e($data->content); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
  <div class="card-footer">
    <a onclick="history.go(-1);" class="btn btn-block btn-outline-secondary">Quay lại</a>
  </div>
  <!-- /.card-footer -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tracking-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/delineco/sys.deli4ne1.com/resources/views/tracking-view.blade.php ENDPATH**/ ?>