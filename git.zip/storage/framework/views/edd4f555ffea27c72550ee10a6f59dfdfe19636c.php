<?php $__env->startSection('head'); ?>
<title>DELI | Quản lý ca làm việc</title>
<link rel="stylesheet" href="<?php echo e(secure_asset('plugins/select2/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(secure_asset('plugins/iCheck/all.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>QUẢN LÝ CA LÀM VIỆC</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Trang chủ</a></li>
            <li class="breadcrumb-item active">Quản lý ca làm việc</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <?php if(count($errors) > 0): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <h4><i class="icon fa fa-ban"></i> Thất bại!</h4> <?php echo $error; ?>

      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      <?php if(isset($warning)): ?>
      <div class="row">
        <div class="col-md-12">
          <div class="alert alert-warning alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h5><i class="icon fa fa-warning"></i> Lưu ý!</h5>
            <?php echo e($warning); ?>

          </div>
        </div>
      </div>
      <?php endif; ?>
      <input type="hidden" name="staff_id" value="<?php echo e(UserInfo()->id); ?>" />
      <div class="row">
        <div class="col-md-12">
          <div class="card card-primary">
            <form role="form" action="<?php echo e(route('staff.shift.manager.post')); ?>" method="post">
              <?php echo e(csrf_field()); ?>

              <div class="card-body">
                <table class="table table-bordered">
                  <tbody>
                    <tr>
                      <th>Buổi</th>
                      <?php $__currentLoopData = $dayofweek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d => $dow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <th><?php echo e($dow); ?> <br> (<?php echo e(DateFormat($next_days[$d])); ?>)</th>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php $__currentLoopData = $sessionofday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s => $sod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($sod); ?></td>
                      <?php $__currentLoopData = $next_days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <td>
                        <?php if(isset($allshift[$s][$day])): ?>
                        <?php $__currentLoopData = $allshift[$s][$day]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group">
                          <label>
                            <input type="hidden" name="accept[<?php echo e($shift->id); ?>]" class="minimal" value="0">
                            <input type="checkbox" name="accept[<?php echo e($shift->id); ?>]" class="minimal" value="1" <?php if($shift->is_accept): ?> checked <?php endif; ?> >
                            <?php echo e($shift->staff->name); ?>

                          </label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </td>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            <div class="card-footer">
              <button type="submit" class="btn btn-primary pull-right">Lưu lịch làm việc</button>
            </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- bootstrap datepicker -->
<script language="JavaScript" type="text/javascript" src="<?php echo e(asset('/plugins/jquery/jquery.min.js')); ?>"></script>
<script language="JavaScript" type="text/javascript" src="<?php echo e(asset('/plugins/select2/select2.full.min.js')); ?>"></script>
<script language="JavaScript" type="text/javascript" src="<?php echo e(asset('/plugins/ckeditor/ckeditor.js')); ?>"></script>
<script language="JavaScript" type="text/javascript" src="<?php echo e(asset('/plugins/iCheck/icheck.min.js')); ?>"></script>
<script>
  $(function() {
    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass: 'iradio_minimal-blue'
    })
  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/delineco/sys.deli4ne1.com/resources/views/shift-manager.blade.php ENDPATH**/ ?>