<?php $__env->startSection('head'); ?>
<title>DELI | Quản lý lịch làm việc</title>
<link rel="stylesheet" href="<?php echo e(secure_asset('plugins/select2/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(secure_asset('plugins/iCheck/all.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>QUẢN LÝ LỊCH LÀM VIỆC</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Trang chủ</a></li>
            <li class="breadcrumb-item active">Quản lý lịch làm việc</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <?php if(count($errors) > 0): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <h4><i class="icon fa fa-ban"></i> Thất bại!</h4> <?php echo $error; ?>

      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      <?php if(session('success')): ?>
      <div class="row">
        <div class="col-md-12">
          <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <h5><i class="icon fa fa-check"></i> Thành công!</h5>
            <?php echo e(session('success')); ?>

          </div>
        </div>
      </div>
      <?php endif; ?>
      <div class="row">
        <div class="col-md-12">
          <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">LỊCH LÀM VIỆC TUẦN NÀY</h3>
              </div>
              <div class="card-body">
                <table class="table table-bordered">
                  <tbody>
                    <tr>
                      <th>Buổi</th>
                      <?php $__currentLoopData = $dayofweek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d => $dow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <th><?php echo e($dow); ?> <br> (<?php echo e(DateFormat($current_days[$d])); ?>)</th>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php $__currentLoopData = $sessionofday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s => $sod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($sod); ?></td>
                      <?php $__currentLoopData = $current_days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <td>
                        <?php if(isset($current_shifts[$s][$day])): ?>
                        <?php $__currentLoopData = $current_shifts[$s][$day]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group <?php if(UserInfo()->id == $shift->staff->id): ?> text-primary <?php endif; ?> ">
                          <label><i class="fa fa-check" aria-hidden="true"></i>
                            <?php echo e($shift->staff->name); ?>

                          </label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </td>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
      <!-- /.row -->
      <div class="row">
        <div class="col-md-12">
          <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">LỊCH LÀM VIỆC TUẦN SAU</h3>
              </div>
              <div class="card-body">
                <table class="table table-bordered">
                  <tbody>
                    <tr>
                      <th>Buổi</th>
                      <?php $__currentLoopData = $dayofweek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d => $dow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <th><?php echo e($dow); ?> <br> (<?php echo e(DateFormat($next_days[$d])); ?>)</th>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php $__currentLoopData = $sessionofday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s => $sod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($sod); ?></td>
                      <?php $__currentLoopData = $next_days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <td>
                        <?php if(isset($next_shifts[$s][$day])): ?>
                        <?php $__currentLoopData = $next_shifts[$s][$day]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group <?php if(UserInfo()->id == $shift->staff->id): ?> text-primary <?php endif; ?> ">
                          <label><i class="fa fa-check" aria-hidden="true"></i>
                            <?php echo e($shift->staff->name); ?>

                          </label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </td>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
      <!-- /.row -->
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<!-- bootstrap datepicker -->
<script language="JavaScript" type="text/javascript" src="<?php echo e(asset('/plugins/jquery/jquery.min.js')); ?>"></script>
<script language="JavaScript" type="text/javascript" src="<?php echo e(asset('/plugins/select2/select2.full.min.js')); ?>"></script>
<script language="JavaScript" type="text/javascript" src="<?php echo e(asset('/plugins/ckeditor/ckeditor.js')); ?>"></script>
<script language="JavaScript" type="text/javascript" src="<?php echo e(asset('/plugins/iCheck/icheck.min.js')); ?>"></script>
<script>
  $(function() {
    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass: 'iradio_minimal-blue'
    })
  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/delineco/sys.deli4ne1.com/resources/views/shift-view.blade.php ENDPATH**/ ?>