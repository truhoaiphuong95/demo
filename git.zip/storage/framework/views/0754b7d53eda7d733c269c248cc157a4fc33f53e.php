<?php $__env->startSection('head'); ?>
<title>DELI | Thêm hình ảnh</title>
<link rel="stylesheet" href="<?php echo e(secure_asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<style>
  .pagination li {
    padding: 10px;
  }
  .pagination {
    float: right;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>THÊM HÌNH ẢNH</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Trang chủ</a></li>
            <li class="breadcrumb-item active">Thêm hình ảnh</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/delineco/sys.deli4ne1.com/resources/views/picture-add.blade.php ENDPATH**/ ?>